import { default as default_6855ccdb58a0e9dfeed31a4e2b412b9e } from '@/components/admin/leads/LeadHeaderSummary'
import { default as default_0e944649f8b02f1ec15383b35ef8ea1e } from '@/components/admin/leads/ProspectMessageCard'
import { default as default_7a8a414291ed8ae2409945d0b9f4451a } from '@/components/admin/leads/ProspectInfoCard'
import { default as default_19240dde5a26185fc75989cf683420ce } from '@/components/admin/leads/SidebarTreatmentHeader'
import { default as default_91dbfe0b9fd5cc15067552f80285fdad } from '@/components/admin/leads/LeadStatusCell'
import { default as default_db9bf23a5b799950471a8905dab846b4 } from '@/components/admin/leads/LeadPriorityCell'
import { default as default_e1232aa0eeb4b311c64715ae549cc775 } from '@/components/admin/invoices/InvoiceStatusCell'
import { default as default_425d273c210e278ca555256d4d129969 } from '@/components/admin/invoices/InvoicePrintButton'
import { RscEntryLexicalCell as RscEntryLexicalCell_44fe37237e0ebf4470c9990d8cb7b07e } from '@payloadcms/richtext-lexical/rsc'
import { RscEntryLexicalField as RscEntryLexicalField_44fe37237e0ebf4470c9990d8cb7b07e } from '@payloadcms/richtext-lexical/rsc'
import { LexicalDiffComponent as LexicalDiffComponent_44fe37237e0ebf4470c9990d8cb7b07e } from '@payloadcms/richtext-lexical/rsc'
import { LinkFeatureClient as LinkFeatureClient_e70f5e05f09f93e00b997edb1ef0c864 } from '@payloadcms/richtext-lexical/client'
import { BoldFeatureClient as BoldFeatureClient_e70f5e05f09f93e00b997edb1ef0c864 } from '@payloadcms/richtext-lexical/client'
import { ItalicFeatureClient as ItalicFeatureClient_e70f5e05f09f93e00b997edb1ef0c864 } from '@payloadcms/richtext-lexical/client'
import { UnderlineFeatureClient as UnderlineFeatureClient_e70f5e05f09f93e00b997edb1ef0c864 } from '@payloadcms/richtext-lexical/client'
import { ParagraphFeatureClient as ParagraphFeatureClient_e70f5e05f09f93e00b997edb1ef0c864 } from '@payloadcms/richtext-lexical/client'
import { InlineToolbarFeatureClient as InlineToolbarFeatureClient_e70f5e05f09f93e00b997edb1ef0c864 } from '@payloadcms/richtext-lexical/client'
import { FixedToolbarFeatureClient as FixedToolbarFeatureClient_e70f5e05f09f93e00b997edb1ef0c864 } from '@payloadcms/richtext-lexical/client'
import { default as default_e18e0b1cd66492fa8bb12208e1fa6bd9 } from '@/components/admin/graphics/BokengiIcon'
import { default as default_060a819ccb1adf5460dfbcd0b5072fba } from '@/components/admin/graphics/BokengiLogo'
import { default as default_8a7ab0eb7ab5c511aba12e68480bfe5e } from '@/components/BeforeLogin'
import { default as default_b8fcbe3615283b53ea965a7dd9540662 } from '@/components/admin/navigation/DashboardNavLink'
import { R2ClientUploadHandler as R2ClientUploadHandler_85cc02ed84006fcc91d3aff39dda669d } from '@payloadcms/storage-r2/client'
import { default as default_ee0378c15f777b7eafa53d279ac7db10 } from '@/components/admin/dashboard/CommandCenterView'
import { CollectionCards as CollectionCards_f9c02e79a4aed9a3924487c0cd4cafb1 } from '@payloadcms/next/rsc'

/** @type import('payload').ImportMap */
export const importMap = {
  "@/components/admin/leads/LeadHeaderSummary#default": default_6855ccdb58a0e9dfeed31a4e2b412b9e,
  "@/components/admin/leads/ProspectMessageCard#default": default_0e944649f8b02f1ec15383b35ef8ea1e,
  "@/components/admin/leads/ProspectInfoCard#default": default_7a8a414291ed8ae2409945d0b9f4451a,
  "@/components/admin/leads/SidebarTreatmentHeader#default": default_19240dde5a26185fc75989cf683420ce,
  "@/components/admin/leads/LeadStatusCell#default": default_91dbfe0b9fd5cc15067552f80285fdad,
  "@/components/admin/leads/LeadPriorityCell#default": default_db9bf23a5b799950471a8905dab846b4,
  "@/components/admin/invoices/InvoiceStatusCell#default": default_e1232aa0eeb4b311c64715ae549cc775,
  "@/components/admin/invoices/InvoicePrintButton#default": default_425d273c210e278ca555256d4d129969,
  "@payloadcms/richtext-lexical/rsc#RscEntryLexicalCell": RscEntryLexicalCell_44fe37237e0ebf4470c9990d8cb7b07e,
  "@payloadcms/richtext-lexical/rsc#RscEntryLexicalField": RscEntryLexicalField_44fe37237e0ebf4470c9990d8cb7b07e,
  "@payloadcms/richtext-lexical/rsc#LexicalDiffComponent": LexicalDiffComponent_44fe37237e0ebf4470c9990d8cb7b07e,
  "@payloadcms/richtext-lexical/client#LinkFeatureClient": LinkFeatureClient_e70f5e05f09f93e00b997edb1ef0c864,
  "@payloadcms/richtext-lexical/client#BoldFeatureClient": BoldFeatureClient_e70f5e05f09f93e00b997edb1ef0c864,
  "@payloadcms/richtext-lexical/client#ItalicFeatureClient": ItalicFeatureClient_e70f5e05f09f93e00b997edb1ef0c864,
  "@payloadcms/richtext-lexical/client#UnderlineFeatureClient": UnderlineFeatureClient_e70f5e05f09f93e00b997edb1ef0c864,
  "@payloadcms/richtext-lexical/client#ParagraphFeatureClient": ParagraphFeatureClient_e70f5e05f09f93e00b997edb1ef0c864,
  "@payloadcms/richtext-lexical/client#InlineToolbarFeatureClient": InlineToolbarFeatureClient_e70f5e05f09f93e00b997edb1ef0c864,
  "@payloadcms/richtext-lexical/client#FixedToolbarFeatureClient": FixedToolbarFeatureClient_e70f5e05f09f93e00b997edb1ef0c864,
  "@/components/admin/graphics/BokengiIcon#default": default_e18e0b1cd66492fa8bb12208e1fa6bd9,
  "@/components/admin/graphics/BokengiLogo#default": default_060a819ccb1adf5460dfbcd0b5072fba,
  "@/components/BeforeLogin#default": default_8a7ab0eb7ab5c511aba12e68480bfe5e,
  "@/components/admin/navigation/DashboardNavLink#default": default_b8fcbe3615283b53ea965a7dd9540662,
  "@payloadcms/storage-r2/client#R2ClientUploadHandler": R2ClientUploadHandler_85cc02ed84006fcc91d3aff39dda669d,
  "@/components/admin/dashboard/CommandCenterView#default": default_ee0378c15f777b7eafa53d279ac7db10,
  "@payloadcms/next/rsc#CollectionCards": CollectionCards_f9c02e79a4aed9a3924487c0cd4cafb1
}
